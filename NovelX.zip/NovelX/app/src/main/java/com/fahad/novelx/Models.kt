package com.fahad.novelx

data class Book(
    val id: String,
    val title: String,
    val author: String,
    val fileName: String,
    var progress: Int = 0,
    var lastChapter: Int = 0
)

data class Chapter(
    val title: String,
    val text: String
)

data class CharacterProfile(
    val name: String,
    val aliases: MutableSet<String> = linkedSetOf(),
    var voiceName: String? = null,
    var gender: Gender = Gender.UNKNOWN
)

enum class Gender { MALE, FEMALE, UNKNOWN }
