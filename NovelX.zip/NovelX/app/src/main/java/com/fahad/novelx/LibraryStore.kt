package com.fahad.novelx

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

object LibraryStore {
    private const val PREFS = "novelx_library"
    private const val BOOKS = "books"

    fun load(context: Context): MutableList<Book> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(BOOKS, "[]") ?: "[]"
        val array = JSONArray(raw)
        val result = mutableListOf<Book>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result += Book(
                o.getString("id"), o.getString("title"), o.optString("author", "Unknown"),
                o.getString("fileName"), o.optInt("progress", 0), o.optInt("lastChapter", 0)
            )
        }
        return result
    }

    fun save(context: Context, books: List<Book>) {
        val array = JSONArray()
        books.forEach { b ->
            array.put(JSONObject().apply {
                put("id", b.id); put("title", b.title); put("author", b.author)
                put("fileName", b.fileName); put("progress", b.progress); put("lastChapter", b.lastChapter)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(BOOKS, array.toString()).apply()
    }

    fun addOrReplace(context: Context, book: Book) {
        val books = load(context)
        val index = books.indexOfFirst { it.id == book.id }
        if (index >= 0) books[index] = book else books.add(0, book)
        save(context, books)
    }

    fun file(context: Context, book: Book): File = File(File(context.filesDir, "books"), book.fileName)

    fun safeId(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }.take(20)
}
