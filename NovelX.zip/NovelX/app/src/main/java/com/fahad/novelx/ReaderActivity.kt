package com.fahad.novelx

import android.os.Bundle
import android.speech.tts.Voice
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ReaderActivity : AppCompatActivity() {
    private lateinit var book: Book
    private lateinit var chapters: List<Chapter>
    private lateinit var voiceManager: VoiceManager
    private var chapterIndex = 0
    private var playing = false
    private var sentenceIndex = 0
    private var speed = 1.0f
    private val profiles = linkedMapOf<String, CharacterProfile>()
    private var currentSentences = emptyList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reader)
        val id = intent.getStringExtra("bookId") ?: return finish()
        book = LibraryStore.load(this).firstOrNull { it.id == id } ?: return finish()
        chapters = try { EpubParser.parse(LibraryStore.file(this, book)) } catch (e: Exception) {
            Toast.makeText(this, "Cannot open EPUB: ${e.message}", Toast.LENGTH_LONG).show(); return finish()
        }
        chapterIndex = book.lastChapter.coerceIn(0, (chapters.size - 1).coerceAtLeast(0))
        voiceManager = VoiceManager(this, {}, { runOnUiThread { onSpeechDone() } })
        bindViews()
        showChapter()
    }

    private fun bindViews() {
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { changeChapter(-1) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { changeChapter(1) }
        findViewById<Button>(R.id.btnPlay).setOnClickListener { toggleSpeech() }
        findViewById<Button>(R.id.btnCharacters).setOnClickListener { showVoiceManager() }
        findViewById<TextView>(R.id.txtReader).setOnLongClickListener { showWordChanger(); true }
    }

    private fun showChapter() {
        if (chapters.isEmpty()) return
        val chapter = chapters[chapterIndex]
        findViewById<TextView>(R.id.txtChapter).text = "${chapterIndex + 1}/${chapters.size} • ${chapter.title}"
        findViewById<TextView>(R.id.txtReader).text = chapter.text
        currentSentences = chapter.text.split(Regex("(?<=[.!?])\\s+"), limit = 0).filter { it.isNotBlank() }
        sentenceIndex = 0
        detectCharacters(chapter.text)
        book.lastChapter = chapterIndex
        book.progress = ((chapterIndex + 1) * 100 / chapters.size).coerceIn(0, 100)
        LibraryStore.addOrReplace(this, book)
        findViewById<ScrollView>(R.id.scrollReader).scrollTo(0, 0)
    }

    private fun detectCharacters(text: String) {
        CharacterDetector.detectProgressively(text).forEach { name -> profiles.getOrPut(name) { CharacterProfile(name) } }
    }

    private fun changeChapter(delta: Int) {
        val next = chapterIndex + delta
        if (next !in chapters.indices) return
        stopSpeech(); chapterIndex = next; showChapter()
    }

    private fun toggleSpeech() {
        if (!voiceManager.ready) {
            Toast.makeText(this, "System TTS is still starting. Try again.", Toast.LENGTH_SHORT).show(); return
        }
        if (playing) { stopSpeech(); return }
        if (currentSentences.isEmpty()) return
        playing = true
        findViewById<Button>(R.id.btnPlay).text = "■"
        speakCurrentSentence()
    }

    private fun speakCurrentSentence() {
        if (!playing || sentenceIndex !in currentSentences.indices) { stopSpeech(); return }
        val sentence = currentSentences[sentenceIndex]
        val voice = findSpeakerVoice(sentence)
        voiceManager.speak(sentence, voice, speed)
        findViewById<ScrollView>(R.id.scrollReader).post { findViewById<TextView>(R.id.txtReader).let { /* keep reading position stable */ } }
    }

    private fun findSpeakerVoice(sentence: String): Voice? {
        val matched = profiles.keys.firstOrNull { Regex("\\b${Regex.escape(it)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(sentence) }
        val voiceName = matched?.let { VoicePrefs.get(this, book.id, "character:$it") }
            ?: VoicePrefs.get(this, book.id, "narrator")
            ?: VoicePrefs.get(this, book.id, "npc_male")
        return voiceManager.voices().firstOrNull { it.name == voiceName }
    }

    private fun onSpeechDone() {
        if (!playing) return
        sentenceIndex++
        if (sentenceIndex >= currentSentences.size) { stopSpeech(); return }
        speakCurrentSentence()
    }

    private fun stopSpeech() {
        voiceManager.stop(); playing = false; findViewById<Button>(R.id.btnPlay).text = "▶"
    }

    private fun showVoiceManager() {
        if (!voiceManager.ready) { Toast.makeText(this, "System TTS is still starting.", Toast.LENGTH_SHORT).show(); return }
        val voices = voiceManager.voices()
        if (voices.isEmpty()) { Toast.makeText(this, "No system voices were found.", Toast.LENGTH_SHORT).show(); return }
        val names = voices.map { it.name }.toTypedArray()
        val roles = mutableListOf("Narrator", "NPC Male", "NPC Female") + profiles.keys.map { "Character: $it" }
        val roleArray = roles.toTypedArray()
        var selectedRole = 0
        android.app.AlertDialog.Builder(this)
            .setTitle("Voice assignments")
            .setSingleChoiceItems(roleArray, 0) { dialog, which ->
                selectedRole = which
                dialog.dismiss()
                chooseVoice(roleArray[which], names, voices)
            }.setNegativeButton("Close", null).show()
    }

    private fun chooseVoice(role: String, names: Array<String>, voices: List<Voice>) {
        val key = when {
            role == "Narrator" -> "narrator"
            role == "NPC Male" -> "npc_male"
            role == "NPC Female" -> "npc_female"
            role.startsWith("Character: ") -> "character:${role.removePrefix("Character: ")}"
            else -> "narrator"
        }
        val current = VoicePrefs.get(this, book.id, key)
        val checked = current?.let { names.indexOf(it) }?.takeIf { it >= 0 } ?: 0
        android.app.AlertDialog.Builder(this).setTitle("Choose $role")
            .setSingleChoiceItems(names, checked) { dialog, which ->
                VoicePrefs.set(this, book.id, key, names[which])
                dialog.dismiss()
                Toast.makeText(this, "$role assigned", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showWordChanger() {
        val old = EditText(this).apply { hint = "word to replace" }
        val new = EditText(this).apply { hint = "new word" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 10, 30, 0); addView(old); addView(new) }
        android.app.AlertDialog.Builder(this).setTitle("Change word")
            .setMessage("This changes the displayed chapter text for this session.")
            .setView(box).setNegativeButton("Cancel", null)
            .setPositiveButton("Replace") { _, _ ->
                val from = old.text.toString(); val to = new.text.toString()
                if (from.isNotBlank()) findViewById<TextView>(R.id.txtReader).text = chapters[chapterIndex].text.replace(from, to, ignoreCase = true)
            }.show()
    }

    override fun onDestroy() { voiceManager.shutdown(); super.onDestroy() }
}
