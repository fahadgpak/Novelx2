package com.fahad.novelx

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale

class VoiceManager(context: Context, private val onReady: () -> Unit, private val onDone: () -> Unit) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context.applicationContext, this)
    var ready = false
        private set

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            tts.language = Locale.getDefault()
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onError(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) { onDone() }
            })
            onReady()
        }
    }

    fun voices(): List<Voice> = if (ready) tts.voices?.sortedBy { it.name } ?: emptyList() else emptyList()
    fun speak(text: String, voice: Voice?, speed: Float) {
        if (!ready) return
        tts.setSpeechRate(speed)
        if (voice != null) tts.voice = voice
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "novelx")
    }
    fun stop() { tts.stop() }
    fun shutdown() { tts.stop(); tts.shutdown() }
}
