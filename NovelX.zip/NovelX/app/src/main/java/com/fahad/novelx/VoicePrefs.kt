package com.fahad.novelx

import android.content.Context

object VoicePrefs {
    private const val PREF = "novelx_voices"
    private fun key(bookId: String, role: String) = "$bookId:$role"
    fun get(context: Context, bookId: String, role: String): String? = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(key(bookId, role), null)
    fun set(context: Context, bookId: String, role: String, voiceName: String) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(key(bookId, role), voiceName).apply()
}
