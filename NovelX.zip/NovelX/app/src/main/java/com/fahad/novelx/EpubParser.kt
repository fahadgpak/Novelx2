package com.fahad.novelx

import android.text.Html
import android.text.Spanned
import android.os.Build
import java.io.File
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory

object EpubParser {
    fun parse(file: File): List<Chapter> {
        ZipFile(file).use { zip ->
            val container = zip.getInputStream(zip.getEntry("META-INF/container.xml")).use { it.readBytes().toString(Charsets.UTF_8) }
            val opfPath = Regex("rootfile[^>]+full-path=[\\\"']([^\\\"']+)", RegexOption.IGNORE_CASE)
                .find(container)?.groupValues?.get(1) ?: error("Invalid EPUB: OPF not found")
            val opfEntry = zip.getEntry(opfPath) ?: error("Invalid EPUB: OPF entry missing")
            val opfBytes = zip.getInputStream(opfEntry).use { it.readBytes() }
            val factory = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
            val doc = factory.newDocumentBuilder().parse(opfBytes.inputStream())
            val manifest = mutableMapOf<String, String>()
            val items = doc.getElementsByTagNameNS("*", "item")
            for (i in 0 until items.length) {
                val n = items.item(i)
                val id = n.attributes.getNamedItem("id")?.nodeValue ?: continue
                val href = n.attributes.getNamedItem("href")?.nodeValue ?: continue
                val media = n.attributes.getNamedItem("media-type")?.nodeValue ?: ""
                if (media.contains("html") || media.contains("xhtml")) manifest[id] = href
            }
            val spine = doc.getElementsByTagNameNS("*", "itemref")
            val base = opfPath.substringBeforeLast('/', "")
            val chapters = mutableListOf<Chapter>()
            for (i in 0 until spine.length) {
                val idref = spine.item(i).attributes.getNamedItem("idref")?.nodeValue ?: continue
                val href = manifest[idref] ?: continue
                val path = if (base.isBlank()) href else "$base/$href"
                val entry = zip.getEntry(path) ?: zip.getEntry(path.replace("%20", " ")) ?: continue
                val raw = zip.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
                val spanned: Spanned = if (Build.VERSION.SDK_INT >= 24) Html.fromHtml(raw, Html.FROM_HTML_MODE_LEGACY) else Html.fromHtml(raw)
                val text = spanned.toString().replace("\\u0000", "").replace(Regex("\\n{3,}"), "\\n\\n").trim()
                if (text.length < 20) continue
                val title = text.lineSequence().firstOrNull { it.trim().length in 3..100 }?.trim() ?: "Chapter ${chapters.size + 1}"
                chapters += Chapter(title, text)
            }
            return chapters
        }
    }
}
