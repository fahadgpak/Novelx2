package com.fahad.novelx

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var recycler: RecyclerView
    private lateinit var empty: TextView
    private lateinit var count: TextView
    private lateinit var adapter: BookAdapter
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recycler = findViewById(R.id.recyclerBooks)
        empty = findViewById(R.id.txtEmpty)
        count = findViewById(R.id.txtCount)
        adapter = BookAdapter { openBook(it) }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        findViewById<Button>(R.id.btnLibrary).setOnClickListener { showPanel(R.id.panelLibrary) }
        findViewById<Button>(R.id.btnOnline).setOnClickListener { showPanel(R.id.panelOnline) }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<Button>(R.id.btnDownload).setOnClickListener { downloadUrl() }

        handleSharedFile(intent)
        refresh()
    }

    private fun showPanel(id: Int) {
        listOf(R.id.panelLibrary, R.id.panelOnline, R.id.panelSettings).forEach { findViewById<View>(it).visibility = if (it == id) View.VISIBLE else View.GONE }
    }

    private fun showSettings() {
        showPanel(R.id.panelSettings)
        val tts = android.speech.tts.TextToSpeech(this) { status ->
            val view = findViewById<TextView>(R.id.txtVoices)
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                val voices = tts.voices?.size ?: 0
                view.text = "Android System TTS is available.\nDetected voices: $voices\n\nReader defaults: Narrator + NPC Male + NPC Female. Character voices can be assigned as characters are discovered."
                tts.shutdown()
            } else view.text = "Android System TTS is unavailable on this device."
        }
    }

    private fun refresh() {
        val books = LibraryStore.load(this)
        adapter.submit(books)
        count.text = "${books.size} book${if (books.size == 1) "" else "s"}"
        empty.visibility = if (books.isEmpty()) View.VISIBLE else View.GONE
        recycler.visibility = if (books.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openBook(book: Book) {
        if (!LibraryStore.file(this, book).exists()) {
            Toast.makeText(this, "Book file is missing.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, ReaderActivity::class.java).putExtra("bookId", book.id))
    }

    private fun downloadUrl() {
        val url = findViewById<EditText>(R.id.edtUrl).text.toString().trim()
        val status = findViewById<TextView>(R.id.txtDownloadStatus)
        if (!url.startsWith("https://", true)) {
            status.text = "Please use a direct HTTPS EPUB URL."
            return
        }
        findViewById<Button>(R.id.btnDownload).isEnabled = false
        status.text = "Connecting…"
        executor.execute {
            try {
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000; readTimeout = 30000; requestMethod = "GET"; instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "NovelX/1.0")
                }
                connection.connect()
                if (connection.responseCode !in 200..299) error("HTTP ${connection.responseCode}")
                val id = LibraryStore.safeId(url)
                val fileName = "$id.epub"
                val dir = File(filesDir, "books").apply { mkdirs() }
                val file = File(dir, fileName)
                connection.inputStream.use { input -> FileOutputStream(file).use { output -> input.copyTo(output) } }
                // Validate before placing it in the library.
                val chapters = EpubParser.parse(file)
                if (chapters.isEmpty()) error("Downloaded file is not a readable EPUB")
                val title = chapters.first().title.ifBlank { "Downloaded EPUB" }
                val book = Book(id, title.take(100), "Unknown", fileName)
                LibraryStore.addOrReplace(this, book)
                runOnUiThread {
                    status.text = "Downloaded: ${book.title}"
                    findViewById<EditText>(R.id.edtUrl).setText("")
                    refresh(); showPanel(R.id.panelLibrary)
                    findViewById<Button>(R.id.btnDownload).isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Download failed: ${e.message ?: "unknown error"}"
                    findViewById<Button>(R.id.btnDownload).isEnabled = true
                }
            }
        }
    }

    private fun handleSharedFile(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        executor.execute {
            try {
                val dir = File(filesDir, "books").apply { mkdirs() }
                val id = LibraryStore.safeId(uri.toString() + System.currentTimeMillis())
                val file = File(dir, "$id.epub")
                contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { input.copyTo(it) } } ?: error("Cannot read shared file")
                val chapters = EpubParser.parse(file)
                if (chapters.isEmpty()) error("Not a readable EPUB")
                LibraryStore.addOrReplace(this, Book(id, chapters.first().title.take(100), "Unknown", file.name))
                runOnUiThread { refresh(); Toast.makeText(this, "EPUB added to NovelX", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Could not import EPUB: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleSharedFile(intent) }
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }

    private class BookAdapter(private val click: (Book) -> Unit) : RecyclerView.Adapter<BookAdapter.Holder>() {
        private val books = mutableListOf<Book>()
        fun submit(value: List<Book>) { books.clear(); books.addAll(value); notifyDataSetChanged() }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_book, parent, false))
        override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(books[position])
        override fun getItemCount() = books.size
        inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
            fun bind(book: Book) {
                itemView.findViewById<TextView>(R.id.txtTitle).text = book.title
                itemView.findViewById<TextView>(R.id.txtAuthor).text = book.author
                itemView.findViewById<ProgressBar>(R.id.progress).progress = book.progress
                itemView.findViewById<TextView>(R.id.txtProgress).text = "${book.progress}% read"
                itemView.setOnClickListener { click(book) }
            }
        }
    }
}
