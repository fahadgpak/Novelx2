package com.fahad.novelx

object CharacterDetector {
    private val patterns = listOf(
        Regex("\\b([A-Z][a-z]{2,24})\\s+(?:said|asked|replied|shouted|whispered|cried|yelled|muttered|answered)\\b"),
        Regex("\\b(?:said|asked|replied|shouted|whispered|cried|yelled|muttered|answered)\\s+([A-Z][a-z]{2,24})\\b")
    )

    fun detectProgressively(text: String): List<String> {
        val found = linkedSetOf<String>()
        text.lineSequence().forEach { line ->
            patterns.forEach { p -> p.findAll(line).forEach { m -> found += m.groupValues[1] } }
        }
        return found.toList()
    }
}
