# NovelX

NovelX is a from-scratch Android EPUB reader focused on a smooth dark reading experience, online EPUB importing, Android System TTS, progressive character detection, character/role voice assignment, and local word replacements.

## Baseline
- Kotlin
- Android XML views
- Package: `com.fahad.novelx`
- Minimum SDK: 23 (Android 6.0)
- Compile/target SDK: 34
- Gradle: 8.0
- JDK: 17

## Build on GitHub
1. Create a new GitHub repository.
2. Upload this project as the repository contents (not as a nested ZIP folder).
3. Open **Actions → Build NovelX APK → Run workflow**.
4. Open the completed workflow run and download the **NovelX-debug-apk** artifact.

Every push to `main` or `master` also builds the debug APK.

## What is included
- Smooth dark/purple reader UI inspired by the general reading-app layout style, implemented from scratch.
- Local EPUB library.
- Import EPUB through Android's Share action.
- Direct HTTPS EPUB download into the private library.
- EPUB spine/XHTML parsing without a novel-reader source project.
- Progressive character detection while a chapter is opened.
- Android System TTS integration.
- Reader speed control foundation and manual speech control.
- Long-press word replacement for the current displayed chapter.
- GitHub Actions APK build.

## Important
NovelX does not include copyrighted books or a third-party novel catalog. Only download/import books you are allowed to use.
